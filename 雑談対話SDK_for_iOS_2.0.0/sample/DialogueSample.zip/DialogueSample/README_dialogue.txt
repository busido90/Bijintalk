﻿サンプルアプリの使用にあたって

・APIキーの設定方法について
　APIキーは DialogueSample/MainViewController.m 内の
　APIKEY に記載してください。

・OAuth 認証情報の設定方法について。
　OAuth 認証情報は DialogueSample/OAuthReqViewController.m 内の
  OAUTH_CLIENT_ID、OAUTH_CLIENT_SECRET、OAUTH_SCOPE、OAUTH_REDIRECT_URI に記載してください。
　※雑談対話の SCOPE は dialogue となります。
